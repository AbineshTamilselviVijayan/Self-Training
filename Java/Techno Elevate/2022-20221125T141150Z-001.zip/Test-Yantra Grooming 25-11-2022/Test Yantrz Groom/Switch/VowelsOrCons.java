//Vowels or Consosnents using Switch
import java.util.Scanner;
class VowelsOrCons  
{
	static Scanner s=new Scanner(System.in);
	public static void main(String[] args) 
	{
		System.out.println("Enter The Character...");
		char ch=s.next().charAt(0);
		switch (ch)
		{
		case 'A':
		case 'E':
		case 'I':
		case 'O':
		case 'U':System.out.println("Vowel");
					break;
		default:System.out.println("Consonent");
		
		}
	}
}
