//Prime Numbers in range
import java.util.Scanner;
class PrimeRange 
{
	static Scanner s=new Scanner(System.in);
	public static void main(String[] args) 
	{
		System.out.println("Enter The Starting Number");
		int start=s.nextInt();
		System.out.println("Enter The Ending Number");
		int end=s.nextInt();
		int count=0;
		for (int i=start;i<=end ;i++ )
		{
			count=0;
			if(i==1 || i==0)
			{
					System.out.println("Neither Prime Nor Comp :"+i);
			}
				for (int j=1;j<=i ;j++ )
				{
					if(i%j==0)
						count++;
				}
					if(count==2)
						System.out.println("Prime is :"+i);
			
			
		}

	}
}
