//Strong Number
import java.util.*;
class StrongNumber 
{
	static Scanner s=new Scanner(System.in);
	public static void main(String[] args) 
	{
		System.out.println("Enter The Number...");
		int given=s.nextInt();
		int sum=0,fact=1,last=0,temp=given;
		while (given>0)
		{
			fact=1;
			last=given%10;//5
			for (int i=2;i<=last ;i++ )
				fact*=i;

			sum+=fact;
			given/=10;			
		}

		String res=(temp==sum)?"Strong":"Not Strong";
		System.out.println(res);
	}

	
}
