//Armstrong Number
import java.util.Scanner;
class Armstrong 
{
	static Scanner s=new Scanner(System.in);
	public static void main(String[] args) 
	{
		System.out.println("Enter The Number...");
		int given=s.nextInt();
		int temp=given,prod=1,sum=0,count=0,last=0;
		//Counting
		while (given>0)
		{
			given/=10;
			count++;
		}
		//We Got the Count
		given=temp;
		while (given>0)
		{
			last=given%10;
			for (int i=1;i<=count ;i++ )	
				prod*=last;

			sum+=prod;
			prod=1;
			given/=10;
		}
		String res=temp==sum?"Arms":"Not Arms";
		System.out.println(res);
	}
}
