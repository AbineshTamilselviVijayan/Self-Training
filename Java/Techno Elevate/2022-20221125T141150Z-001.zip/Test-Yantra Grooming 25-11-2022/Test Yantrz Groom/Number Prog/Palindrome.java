//Wajp to check Palindrome Or Not
class Palindrome 
{
	public static void main(String[] args) 
	{
		int given=141,rev=0,temp=given;
		while (given>0)
		{
			rev=rev*10+(given%10);
			given/=10;
		}
		String res=(temp==rev)?"Palindrome":"Not Palindrome";
		System.out.println(res);	
	}
}
