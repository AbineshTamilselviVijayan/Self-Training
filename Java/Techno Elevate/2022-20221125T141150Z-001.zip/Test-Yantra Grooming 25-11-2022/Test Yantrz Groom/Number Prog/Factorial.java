//Wajp For Factorial
import java.util.*;
class Factorial 
{
	static Scanner s=new Scanner(System.in);
	public static void main(String[] args) 
	{
		System.out.println("Enter The Number!");
		int given=s.nextInt();
		int fact=1;
		for (int i=2;i<=given ;i++ )
			fact*=i;

		System.out.println("The Factorial is :"+fact);
	}
}
